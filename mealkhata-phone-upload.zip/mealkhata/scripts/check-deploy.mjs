import fs from "node:fs";
import {parse} from "jsonc-parser";
const path = "wrangler.pilot.jsonc";
if (!fs.existsSync(path))
  throw new Error(
    "Copy wrangler.pilot.example.jsonc to wrangler.pilot.jsonc and follow docs/DEPLOYMENT.md first.",
  );
const raw = fs.readFileSync(path, "utf8");
if (raw.includes("REPLACE_"))
  throw new Error("Deployment config still contains placeholders.");
const errors=[];
const cfg = parse(raw,errors,{allowTrailingComma:true});
if(errors.length) throw new Error("Deployment configuration contains invalid JSONC.");
if (cfg.vars?.APP_ENV !== "production" || cfg.vars?.ALLOW_SANDBOX !== "false")
  throw new Error("Production must disable sandbox identities.");
if (
  !cfg.vars?.APP_ORIGIN?.startsWith("https://") ||
  new URL(cfg.vars.APP_ORIGIN).origin !== cfg.vars.APP_ORIGIN
)
  throw new Error("Set an exact HTTPS app origin without a trailing slash.");
console.log(
  "Basic deployment config check passed. OAuth secret, limits, real sign-in and staging checks are still required.",
);
